# ✅ First Time Setup Checklist

**Follow this exact order to get Nifty Racer running in ~15 minutes**

---

## 🎯 Phase 1: Prerequisites (2 minutes)

- [ ] Node.js 18+ installed
  - Check: `node --version` (should be v18+)
  - Install: https://nodejs.org

- [ ] npm working
  - Check: `npm --version`
  - Should come with Node.js

- [ ] Have a wallet (MetaMask, Rainbow, etc.)
  - Install browser extension
  - Create account and backup seed phrase

- [ ] GitHub account (optional, for deployment)
  - Go to https://github.com/signup

---

## 🚀 Phase 2: Install Project (3 minutes)

- [ ] Clone/download project
  ```bash
  git clone <your-repo-url>
  cd nifty-racer
  ```

- [ ] Install dependencies
  ```bash
  npm install
  ```

- [ ] Verify installation
  ```bash
  npm run build
  # Should complete without errors
  ```

---

## ⚙️ Phase 3: Blockchain Setup (5 minutes)

### Get WalletConnect Project ID

- [ ] Visit: https://cloud.walletconnect.com

- [ ] Create new project
  - Click "Create a new project"
  - Name it: "Nifty Racer"
  - Select "Web3 Wallet"

- [ ] Copy Project ID
  - View dashboard
  - Copy the "Project ID" value
  - Keep it handy

### Add to Code

- [ ] Update `/lib/wagmi.ts`
  ```typescript
  // Line 5 - Replace YOUR_WALLETCONNECT_PROJECT_ID
  const WALLETCONNECT_PROJECT_ID = 'paste_your_id_here'
  ```

---

## 🔗 Phase 4: Wallet Setup (3 minutes)

### Add Base Sepolia Network

- [ ] Open wallet (MetaMask, Rainbow, etc.)

- [ ] Click network dropdown (top left)

- [ ] Click "Add Network" or "Add Custom Network"

- [ ] Fill in details:
  ```
  Network Name:    Base Sepolia
  RPC URL:         https://sepolia.base.org
  Chain ID:        84532
  Currency Symbol: ETH
  Explorer:        https://sepolia.basescan.org
  ```

- [ ] Save and select Base Sepolia network

- [ ] Verify: Connected to "Base Sepolia" in wallet

### Get Testnet ETH

- [ ] Visit faucet: https://www.coinbase.com/faucets/base-ethereum-sepolia-faucet

- [ ] Copy your wallet address
  - Click on wallet address to copy
  - Paste into faucet website

- [ ] Request ETH
  - Fill form with your address
  - Click "Send me ETH"
  - Wait 1-2 minutes

- [ ] Verify in wallet
  - Refresh wallet
  - Should show ~0.5-1 ETH

---

## 🎮 Phase 5: Run Locally (2 minutes)

- [ ] Start dev server
  ```bash
  npm run dev
  ```

- [ ] Wait for completion
  - Should see: "ready on http://localhost:3000"

- [ ] Open browser
  - Go to: http://localhost:3000
  - Should see purple title "NIFTY RACER"

---

## ✨ Phase 6: Test Wallet Connection (2 minutes)

- [ ] Click "Connect Wallet" button
  - Button appears on page

- [ ] Choose wallet
  - Select MetaMask / Rainbow / WalletConnect
  - Approve in extension

- [ ] Verify connection
  - [ ] See wallet address on page
  - [ ] See ETH balance (should be ~0.5-1)
  - [ ] See "Base Sepolia (Testnet)" badge
  - [ ] "START RACE" button is now enabled

- [ ] ✅ Success! You're connected!

---

## 📝 Phase 7: Verify Everything

- [ ] Home page loads ✅
- [ ] Wallet connects ✅
- [ ] ETH balance shows ✅
- [ ] Buttons are responsive ✅
- [ ] No console errors ✅
  - Check DevTools (F12) → Console tab

- [ ] Try disconnecting/reconnecting
  - Click address dropdown → Disconnect
  - Click Connect again
  - Should work smoothly

---

## 🚀 Phase 8: Optional - Deploy to Vercel

- [ ] (Skip if not ready to deploy)

- [ ] Create GitHub repo
  ```bash
  git init
  git add .
  git commit -m "Initial commit"
  git remote add origin https://github.com/YOUR_USERNAME/nifty-racer.git
  git push -u origin main
  ```

- [ ] Go to https://vercel.com/new

- [ ] Import repository

- [ ] Add environment variable:
  - Key: `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID`
  - Value: `your_project_id`

- [ ] Deploy

- [ ] Wait for deployment (~60 seconds)

- [ ] Click deployment URL

- [ ] Test wallet connection on live site

---

## 🎉 You're Done! (15-20 minutes total)

```
✅ All setup complete!
✅ Project running locally
✅ Wallet connected
✅ Ready to build!
```

---

## 📚 Next Steps

### Recommended Order

1. **Explore the code** (10 minutes)
   - Read `/app/page.tsx`
   - Understand home page structure
   - Check `/lib/wagmi.ts`

2. **Read documentation** (20 minutes)
   - [`/README.md`](/README.md) - Overview
   - [`/QUICK_REFERENCE.md`](/QUICK_REFERENCE.md) - Architecture

3. **Build features** (ongoing)
   - Start with `/app/race/page.tsx`
   - Implement game logic
   - Add smart contracts

4. **Deploy** (when ready)
   - Follow [`/DEPLOY.md`](/DEPLOY.md)
   - Push to GitHub
   - Deploy to Vercel

---

## 🐛 Stuck? Quick Fixes

### "Module not found" error
```bash
npm install
npm run dev
```

### "WalletConnect Project ID" error
- Edit `/lib/wagmi.ts` line 5
- Replace with real Project ID from cloud.walletconnect.com

### Wallet not connecting
- Ensure Base Sepolia added to wallet
- Clear browser cache (Ctrl+Shift+Delete)
- Try incognito mode

### No ETH balance showing
- Check wallet is on Base Sepolia network
- Go to faucet and request more ETH
- Wait 1-2 minutes for confirmation
- Refresh page

### More help?
- See [`/SETUP.md`](/SETUP.md) Troubleshooting section (comprehensive)
- Check `/INDEX.md` for documentation links

---

## ✅ Phase Completion Tracking

Record your progress:

```
Phase 1 (Prerequisites):     ✅ Done at _______
Phase 2 (Install):          ✅ Done at _______
Phase 3 (Blockchain):       ✅ Done at _______
Phase 4 (Wallet):           ✅ Done at _______
Phase 5 (Run Local):        ✅ Done at _______
Phase 6 (Test):             ✅ Done at _______
Phase 7 (Verify):           ✅ Done at _______
Phase 8 (Deploy):           ✅ Done at _______ (optional)

Total time: _______ minutes
```

---

## 🎮 You're Ready to Build!

Now that everything is working:

1. **Understand the code** - Read the files mentioned above
2. **Make small changes** - Edit `/app/page.tsx` and see live reload
3. **Build game features** - Start with `/app/race/page.tsx`
4. **Connect smart contracts** - Use examples in `/lib/abi.ts`
5. **Deploy when ready** - Follow `/DEPLOY.md`

---

## 💡 Pro Tips

- **Hot Reload**: Changes save automatically, just refresh browser
- **DevTools**: Press F12 to see errors and debug
- **Console Logs**: Add `console.log()` to trace execution
- **Incognito Mode**: Useful for fresh testing
- **Mobile Testing**: Open DevTools → Device mode

---

## 📞 Still Need Help?

1. Check `/SETUP.md` Troubleshooting
2. Read `/QUICK_REFERENCE.md`
3. Visit https://discord.gg/Z8n5aXJbvd (wagmi community)
4. Check wagmi docs: https://wagmi.sh

---

**Congrats on getting Nifty Racer up and running! 🏁**

**Next: Read /README.md and explore the code! 🚀**
