# 📚 Documentation Index - Nifty Racer

**Start here!** Find the guide you need:

---

## 🚀 Getting Started (Choose One)

### I just cloned the project
→ **Read**: [`/SETUP.md`](/SETUP.md) (286 lines)
- Step-by-step installation guide
- WalletConnect setup
- Add Base Sepolia to wallet
- Get testnet ETH
- Run locally

### I want to understand the architecture
→ **Read**: [`/QUICK_REFERENCE.md`](/QUICK_REFERENCE.md) (275 lines)
- Project structure diagram
- File organization
- Color palette & design system
- Blockchain setup details
- Key concepts explained

### I'm ready to deploy to production
→ **Read**: [`/DEPLOY.md`](/DEPLOY.md) (385 lines)
- Push to GitHub
- Deploy to Vercel
- Add environment variables
- Monitor performance
- Troubleshoot issues

### I want the complete overview
→ **Read**: [`/README.md`](/README.md) (206 lines)
- Project description
- Feature list
- Blockchain integration
- Resource links
- Common issues

### I need a project summary
→ **Read**: [`/SETUP_SUMMARY.md`](/SETUP_SUMMARY.md) (472 lines)
- What's included
- Generated files list
- Architecture overview
- Next steps
- Pro tips

---

## 📁 Code Files Guide

### Must-Know Files

```
/app/page.tsx
├─ The main home page
├─ Wallet connection UI
├─ Balance display
└─ "START RACE" button

/lib/wagmi.ts
├─ Blockchain configuration
├─ Base Sepolia setup
├─ WalletConnect config
└─ RPC endpoint

/app/layout.tsx
├─ Root layout (server)
├─ Metadata & SEO
└─ HTML structure

/app/layout-client.tsx
├─ Client providers wrapper
├─ wagmi setup
├─ RainbowKit provider
└─ React Query setup

/app/globals.css
├─ Tailwind configuration
├─ Synthwave theme colors
├─ Neon glow effects
└─ Responsive utilities
```

### Configuration Files

```
/lib/config.ts
├─ Game settings
├─ Contract addresses (TODO)
├─ UI configuration
└─ Faucet links

/lib/web3-utils.ts
├─ Address formatting
├─ Balance conversion
├─ Network validation
└─ Explorer URLs

/lib/abi.ts
├─ Contract ABI templates
├─ Example functions
└─ Event definitions
```

### Route Placeholders

```
/app/race/page.tsx
├─ 🏎️ Main game (TODO)
├─ Canvas rendering
└─ Scoring system

/app/shop/page.tsx
├─ 🛍️ NFT marketplace (TODO)
├─ Car cosmetics
└─ Purchase flow

/app/leaderboard/page.tsx
├─ 🏆 Leaderboard (TODO)
├─ Top scores
└─ Player stats
```

---

## 🎨 Customization Quick Links

### Change Colors
→ Edit: `/app/globals.css` lines 41-48
```css
--neon-pink: #ff006e;
--neon-purple: #8338ec;
```

### Change App Name
→ Edit: `/lib/wagmi.ts` line 11
```typescript
appName: 'YOUR_APP_NAME'
```

### Add More Networks
→ Edit: `/lib/wagmi.ts` chains array
```typescript
chains: [baseSepolia, otherNetwork]
```

### Update Contract Addresses
→ Edit: `/lib/config.ts` CONTRACTS section
```typescript
GAME_TOKEN: '0x...'
```

---

## 🔍 Common Tasks

### How do I...

**...connect a wallet?**
- Code: `/app/page.tsx` line 25
- Hook: `useAccount()` from wagmi
- Component: `<ConnectButton />` from RainbowKit

**...get the user's balance?**
- Hook: `useBalance()` from wagmi
- Code: `/app/page.tsx` line 13
- Display: Shows ETH balance on home page

**...call a smart contract?**
- Use: `useContractRead()` / `useContractWrite()`
- ABI: `/lib/abi.ts` has templates
- Example: See comments in `/lib/abi.ts`

**...add a new route?**
- Create: `/app/route-name/page.tsx`
- Auto-routed: `/route-name`
- Example: `/app/leaderboard/page.tsx` → `/leaderboard`

**...customize styling?**
- Colors: `/app/globals.css` `:root` section
- Layouts: Tailwind classes in JSX
- Fonts: Already configured (Geist + Geist Mono)

**...deploy to Vercel?**
- Push to GitHub
- Go to vercel.com/new
- Follow setup in `/DEPLOY.md`

---

## 🐛 Troubleshooting

### Quick Fixes

**Wallet not connecting?**
→ Read: `/SETUP.md` → Troubleshooting section

**No ETH balance showing?**
→ Check: 1) On Base Sepolia 2) Got testnet ETH 3) Refreshed page

**Build fails?**
→ Run: `npm install` and `npm run build`

**Styles not working?**
→ Check: RainbowKit CSS import in `/app/globals.css` line 3

**RPC errors?**
→ Verify: Base Sepolia RPC URL in `/lib/wagmi.ts`

**More help?**
→ Read: `/SETUP.md` Troubleshooting (comprehensive list)

---

## 📊 Project Stats

```
Total Files:        15+
Code Lines:         ~2000
Documentation:      ~1200 lines
TypeScript:         100% coverage
Mobile Responsive:  ✅
Testnet Ready:      ✅
Deploy Ready:       ✅
```

---

## 🎯 Recommended Reading Order

### First Time?

1. [`/README.md`](/README.md) - Understand what this is
2. [`/SETUP.md`](/SETUP.md) - Get it running locally
3. [`/app/page.tsx`](/app/page.tsx) - See how it works
4. [`/lib/wagmi.ts`](/lib/wagmi.ts) - Blockchain setup

### Before Deploying?

1. [`/DEPLOY.md`](/DEPLOY.md) - Deployment guide
2. [`/SETUP.md`](/SETUP.md) → Troubleshooting - Common issues
3. `/package.json` - Verify dependencies

### For Development?

1. [`/QUICK_REFERENCE.md`](/QUICK_REFERENCE.md) - Architecture
2. [`/lib/web3-utils.ts`](/lib/web3-utils.ts) - Helper functions
3. [`/lib/config.ts`](/lib/config.ts) - Configuration
4. [`/lib/abi.ts`](/lib/abi.ts) - Contract templates

---

## 📞 Need Help?

### Documentation First
1. Check this index → find relevant guide
2. Read the guide's troubleshooting section
3. Search in documentation files

### Online Resources
- [wagmi Docs](https://wagmi.sh)
- [RainbowKit Docs](https://www.rainbowkit.com)
- [Base Docs](https://docs.base.org)
- [Next.js Docs](https://nextjs.org/docs)

### Communities
- wagmi Discord: https://discord.gg/Z8n5aXJbvd
- Base Discord: https://discord.gg/buildonbase
- Ethereum Stack Exchange: https://ethereum.stackexchange.com

---

## ✅ Quick Checklist

Getting started? Check these off:

- [ ] Cloned repo: `git clone`
- [ ] Installed deps: `npm install`
- [ ] Read `/SETUP.md`
- [ ] Got WalletConnect Project ID
- [ ] Added Project ID to `/lib/wagmi.ts`
- [ ] Added Base Sepolia to wallet
- [ ] Got testnet ETH from faucet
- [ ] Running: `npm run dev`
- [ ] Wallet connects on localhost:3000
- [ ] See ETH balance displayed
- [ ] Ready to deploy!

---

## 🚀 Next Steps

```
1. ✅ Follow /SETUP.md
   ↓
2. ✅ Connect wallet locally
   ↓
3. ✅ Follow /DEPLOY.md
   ↓
4. ✅ Deploy to Vercel
   ↓
5. 🏗️ Build game features
   ↓
6. 📝 Deploy smart contracts
   ↓
7. 🎮 Launch on testnet
   ↓
8. 🚀 Go mainnet (eventually!)
```

---

## 📚 File Reference

| File | Type | Lines | Purpose |
|------|------|-------|---------|
| `/README.md` | 📖 | 206 | Main documentation |
| `/SETUP.md` | 📖 | 286 | Setup guide |
| `/DEPLOY.md` | 📖 | 385 | Deployment guide |
| `/QUICK_REFERENCE.md` | 📖 | 275 | Architecture reference |
| `/SETUP_SUMMARY.md` | 📖 | 472 | Implementation summary |
| `/INDEX.md` | 📖 | This | Navigation guide |
| `/app/page.tsx` | 💻 | 124 | Home page |
| `/lib/wagmi.ts` | ⚙️ | 16 | Blockchain config |
| `/lib/config.ts` | ⚙️ | 53 | Game config |
| `/lib/web3-utils.ts` | ⚙️ | 82 | Web3 helpers |
| `/lib/abi.ts` | ⚙️ | 116 | Contract ABIs |
| `/app/globals.css` | 🎨 | 179 | Styling & theme |

---

**Created with ❤️ - Ready to build? Start with `/SETUP.md`!** 🏁

Last updated: January 2026
