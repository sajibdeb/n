/**
 * Web3 utilities and helpers for Nifty Racer
 * Includes wallet validation, address formatting, and wagmi helpers
 */

import { Address } from 'viem'

/**
 * Format wallet address to short format
 * @param address Full wallet address
 * @returns Shortened format: 0x1234...5678
 */
export function formatAddress(address: string | Address | undefined): string {
  if (!address) return ''
  const str = String(address)
  return `${str.slice(0, 6)}...${str.slice(-4)}`
}

/**
 * Format balance with decimals
 * @param balance Balance string
 * @param decimals Number of decimal places
 * @returns Formatted balance string
 */
export function formatBalance(balance: string, decimals: number = 4): string {
  const num = Number(balance)
  return num.toFixed(decimals)
}

/**
 * Convert wei to ETH
 * @param wei Amount in wei
 * @returns Amount in ETH
 */
export function weiToEth(wei: string | bigint): string {
  const weiNum = typeof wei === 'string' ? BigInt(wei) : wei
  const ethNum = Number(weiNum) / 1e18
  return ethNum.toFixed(4)
}

/**
 * Validate if string is valid Ethereum address
 * @param address Address to validate
 * @returns True if valid address
 */
export function isValidAddress(address: string): boolean {
  return /^0x[a-fA-F0-9]{40}$/.test(address)
}

/**
 * Get explorer URL for address on Base Sepolia
 * @param address Wallet address
 * @returns BaseScan URL
 */
export function getExplorerUrl(address: string): string {
  return `https://sepolia.basescan.org/address/${address}`
}

/**
 * Get explorer URL for transaction on Base Sepolia
 * @param txHash Transaction hash
 * @returns BaseScan URL
 */
export function getTxExplorerUrl(txHash: string): string {
  return `https://sepolia.basescan.org/tx/${txHash}`
}

/**
 * Check if user is connected to correct network (Base Sepolia)
 * @param chainId Current chain ID
 * @returns True if on Base Sepolia
 */
export function isOnBaseSepoliaTestnet(chainId: number): boolean {
  return chainId === 84532
}

// TODO: Add more utilities as needed
// - Score formatting
// - Leaderboard sorting
// - Game state helpers
// - Contract interaction helpers
