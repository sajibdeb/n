/**
 * Example Smart Contract ABI for Nifty Racer
 * 
 * This is a template. Replace with your actual contract ABI
 * when you deploy smart contracts to Base Sepolia.
 * 
 * To get the ABI:
 * 1. Deploy your contract using Hardhat/Foundry
 * 2. Copy the ABI from artifacts/YourContract.json
 * 3. Replace this file with your actual ABI
 * 4. Update contract addresses in /lib/config.ts
 */

export const GAME_CONTRACT_ABI = [
  {
    type: 'function',
    name: 'submitScore',
    inputs: [
      { name: 'score', type: 'uint256', internalType: 'uint256' },
      { name: 'time', type: 'uint256', internalType: 'uint256' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'getPlayerScore',
    inputs: [{ name: 'player', type: 'address', internalType: 'address' }],
    outputs: [{ name: '', type: 'uint256', internalType: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'getLeaderboard',
    inputs: [{ name: 'limit', type: 'uint256', internalType: 'uint256' }],
    outputs: [
      {
        name: '',
        type: 'tuple[]',
        internalType: 'struct Game.Player[]',
        components: [
          { name: 'player', type: 'address', internalType: 'address' },
          { name: 'score', type: 'uint256', internalType: 'uint256' },
          { name: 'timestamp', type: 'uint256', internalType: 'uint256' },
        ],
      },
    ],
    stateMutability: 'view',
  },
  {
    type: 'event',
    name: 'ScoreSubmitted',
    inputs: [
      { name: 'player', type: 'address', indexed: true, internalType: 'address' },
      { name: 'score', type: 'uint256', indexed: false, internalType: 'uint256' },
      { name: 'timestamp', type: 'uint256', indexed: false, internalType: 'uint256' },
    ],
  },
] as const

// Example ERC-721 NFT ABI for car skins
export const NFT_SHOP_ABI = [
  {
    type: 'function',
    name: 'mint',
    inputs: [
      { name: 'to', type: 'address', internalType: 'address' },
      { name: 'tokenId', type: 'uint256', internalType: 'uint256' },
    ],
    outputs: [],
    stateMutability: 'nonpayable',
  },
  {
    type: 'function',
    name: 'balanceOf',
    inputs: [{ name: 'owner', type: 'address', internalType: 'address' }],
    outputs: [{ name: '', type: 'uint256', internalType: 'uint256' }],
    stateMutability: 'view',
  },
  {
    type: 'function',
    name: 'tokenURI',
    inputs: [{ name: 'tokenId', type: 'uint256', internalType: 'uint256' }],
    outputs: [{ name: '', type: 'string', internalType: 'string' }],
    stateMutability: 'view',
  },
  {
    type: 'event',
    name: 'Transfer',
    inputs: [
      { name: 'from', type: 'address', indexed: true, internalType: 'address' },
      { name: 'to', type: 'address', indexed: true, internalType: 'address' },
      { name: 'tokenId', type: 'uint256', indexed: true, internalType: 'uint256' },
    ],
  },
] as const

/**
 * Usage Example:
 * 
 * import { useContractRead } from 'wagmi'
 * import { GAME_CONTRACT_ABI } from '@/lib/abi'
 * import { CONFIG } from '@/lib/config'
 * 
 * export function MyComponent() {
 *   const { data: score } = useContractRead({
 *     address: CONFIG.CONTRACTS.GAME_TOKEN as `0x${string}`,
 *     abi: GAME_CONTRACT_ABI,
 *     functionName: 'getPlayerScore',
 *     args: ['0x...'], // user address
 *   })
 * 
 *   return <div>Score: {score?.toString()}</div>
 * }
 */
