import { getDefaultConfig } from '@rainbow-me/rainbowkit'
import { baseSepolia } from 'viem/chains'
import { http } from 'viem'

// NOTE: WalletConnect projectId - add your own from https://cloud.walletconnect.com
const WALLETCONNECT_PROJECT_ID = 'YOUR_WALLETCONNECT_PROJECT_ID'

export const wagmiConfig = getDefaultConfig({
  appName: 'Nifty Racer (Testnet)',
  projectId: WALLETCONNECT_PROJECT_ID,
  chains: [baseSepolia],
  transports: {
    [baseSepolia.id]: http('https://sepolia.base.org'),
  },
})
