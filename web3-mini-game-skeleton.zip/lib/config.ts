// Configuration template for Nifty Racer (Testnet)
// Copy values here and update environment variables as needed

export const CONFIG = {
  // Blockchain
  BLOCKCHAIN: {
    CHAIN_ID: 84532, // Base Sepolia
    CHAIN_NAME: 'Base Sepolia',
    RPC_URL: 'https://sepolia.base.org',
  },

  // WalletConnect (required for multi-chain wallet support)
  // Get your Project ID at: https://cloud.walletconnect.com
  WALLETCONNECT: {
    PROJECT_ID: process.env.NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID || 'YOUR_PROJECT_ID_HERE',
  },

  // Game Settings
  GAME: {
    APP_NAME: 'Nifty Racer (Testnet)',
    VERSION: '0.1.0',
    TESTNET_MODE: true,
  },

  // Smart Contract Addresses (TODO: Deploy and add)
  CONTRACTS: {
    GAME_TOKEN: '0x0000000000000000000000000000000000000000', // TODO: Deploy game token
    LEADERBOARD: '0x0000000000000000000000000000000000000000', // TODO: Deploy leaderboard contract
    NFT_SHOP: '0x0000000000000000000000000000000000000000', // TODO: Deploy NFT contract
  },

  // UI/UX Settings
  UI: {
    THEME: 'dark',
    ANIMATION_DURATION: 300, // ms
    MOBILE_BREAKPOINT: 768, // px
  },

  // Faucets for testnet ETH
  FAUCETS: [
    {
      name: 'Coinbase Faucet',
      url: 'https://www.coinbase.com/faucets/base-ethereum-sepolia-faucet',
    },
    {
      name: 'PK910 Faucet',
      url: 'https://sepolia-faucet.pk910.de',
    },
  ],
}

export default CONFIG
