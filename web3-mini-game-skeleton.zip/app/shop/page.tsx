'use client'

// TODO: Build the shop interface here
// Players can purchase car skins, upgrades, and other cosmetics
// Use wagmi hooks to handle blockchain transactions

export default function ShopPage() {
  return (
    <main className="synthwave-bg min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-600 mb-4">
          🛍️ Shop
        </h1>
        <p className="text-gray-400 mb-8">Car skins, upgrades, and cosmetics coming soon...</p>
        
        {/* TODO: Display NFT marketplace items, handle purchases with wagmi writeContract */}
      </div>
    </main>
  )
}
