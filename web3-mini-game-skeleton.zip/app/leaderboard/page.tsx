'use client'

// TODO: Build the leaderboard here
// Display top players' scores and race times
// Fetch data from contract or backend API

export default function LeaderboardPage() {
  return (
    <main className="synthwave-bg min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-purple-600 mb-4">
          🏆 Leaderboard
        </h1>
        <p className="text-gray-400 mb-8">Global rankings and stats coming soon...</p>
        
        {/* TODO: Display top players with wagmi hooks to read from smart contract, pagination, filters */}
      </div>
    </main>
  )
}
