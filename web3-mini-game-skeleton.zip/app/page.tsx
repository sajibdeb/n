'use client'

import { useAccount, useBalance } from 'wagmi'
import { ConnectButton } from '@rainbow-me/rainbowkit'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'

export default function HomePage() {
  const { address, isConnected } = useAccount()
  const { data: balance } = useBalance({ address })

  const handleStartRace = () => {
    if (!isConnected) {
      alert('Please connect your wallet first!')
      return
    }
    // TODO: Navigate to /race route when ready
    alert('🚀 Starting race... (Route /race coming soon!)')
  }

  return (
    <main className="synthwave-bg min-h-screen flex flex-col items-center justify-center px-4 py-12">
      {/* Animated grid background overlay */}
      <div className="fixed inset-0 pointer-events-none opacity-30">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-pink-500/10"></div>
      </div>

      <div className="relative z-10 w-full max-w-2xl">
        {/* Main content */}
        <div className="text-center mb-12">
          {/* Title with neon glow */}
          <h1 className="text-6xl md:text-7xl font-black font-mono mb-4 neon-text-glow">
            NIFTY
            <br />
            RACER
          </h1>

          {/* Subtitle */}
          <p className="text-lg md:text-xl text-gray-300 mb-2 leading-relaxed">
            Neon pixel endless racer on Base
          </p>
          <p className="text-sm md:text-base text-purple-300/80">
            testnet mode: free gas plays, earn mock points
          </p>
        </div>

        {/* Wallet Connection Section */}
        <div className="mb-12 flex justify-center">
          <div className="neon-glow-purple p-2 rounded-lg">
            <ConnectButton />
          </div>
        </div>

        {/* Connected wallet info */}
        {isConnected && address && (
          <Card className="bg-[#1a1f3a] border-purple-500/50 mb-8 p-6 neon-glow-purple">
            <div className="space-y-4">
              <div>
                <p className="text-gray-400 text-sm mb-1">Wallet Address</p>
                <p className="text-white font-mono text-sm break-all">{address}</p>
              </div>

              {balance && (
                <div>
                  <p className="text-gray-400 text-sm mb-1">Base Sepolia ETH Balance</p>
                  <p className="text-cyan-300 font-semibold text-lg">
                    {balance.formatted} {balance.symbol}
                  </p>
                </div>
              )}

              <div>
                <p className="text-gray-400 text-sm mb-1">Network</p>
                <p className="text-green-300 font-semibold">Base Sepolia (Testnet)</p>
              </div>
            </div>
          </Card>
        )}

        {/* Start Race Button */}
        <div className="flex justify-center mb-12">
          <Button
            onClick={handleStartRace}
            className="neon-button-glow px-8 py-3 text-lg font-bold bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white rounded-lg border border-pink-500/50"
          >
            {isConnected ? '🏁 START RACE (Testnet)' : '⚡ Connect Wallet First'}
          </Button>
        </div>

        {/* Future routes placeholder */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-16">
          <Card className="bg-[#1a1f3a]/50 border-purple-500/30 p-4 text-center">
            <p className="text-gray-400 text-sm">
              🏎️ /race
              <br />
              <span className="text-xs text-gray-500">Coming soon</span>
            </p>
          </Card>
          <Card className="bg-[#1a1f3a]/50 border-purple-500/30 p-4 text-center">
            <p className="text-gray-400 text-sm">
              🛍️ /shop
              <br />
              <span className="text-xs text-gray-500">Coming soon</span>
            </p>
          </Card>
          <Card className="bg-[#1a1f3a]/50 border-purple-500/30 p-4 text-center">
            <p className="text-gray-400 text-sm">
              🏆 /leaderboard
              <br />
              <span className="text-xs text-gray-500">Coming soon</span>
            </p>
          </Card>
        </div>

        {/* Footer notes */}
        <div className="mt-16 text-center text-xs text-gray-500 space-y-2">
          <p>💡 This is a testnet-only app. Use free Base Sepolia ETH.</p>
          <p>🔗 Powered by wagmi v2 + RainbowKit + Base Sepolia</p>
        </div>
      </div>
    </main>
  )
}
