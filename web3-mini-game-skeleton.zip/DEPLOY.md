# 🚀 Deployment Guide - Nifty Racer to Vercel

Complete guide to deploy your Web3 gaming app to Vercel with live Base Sepolia integration.

## Prerequisites

- ✅ Project running locally with `npm run dev`
- ✅ GitHub account (free tier works)
- ✅ Vercel account (free tier works)
- ✅ WalletConnect Project ID set in `/lib/wagmi.ts`

## Step 1: Push to GitHub

### First Time Setup

```bash
# Initialize git (if not already done)
git init
git add .
git commit -m "Initial commit: Nifty Racer Web3 game skeleton"

# Create a new repository on GitHub:
# 1. Go to https://github.com/new
# 2. Name it "nifty-racer"
# 3. Click "Create repository"
# 4. Follow the instructions to push existing code

git remote add origin https://github.com/YOUR_USERNAME/nifty-racer.git
git branch -M main
git push -u origin main
```

### Subsequent Pushes

```bash
git add .
git commit -m "Your commit message"
git push
```

## Step 2: Deploy to Vercel

### Method A: Vercel CLI (Recommended)

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy from project directory
vercel

# Follow the prompts:
# ? Set up and deploy "~/nifty-racer"? (Y/n) → Y
# ? Which scope do you want to deploy to? → Your account
# ? Link to existing project? (y/N) → N (first time)
# ? What's your project's name? → nifty-racer
# ? In which directory is your code? → . (current)
# ? Want to modify these settings? (y/N) → N
```

### Method B: Vercel Dashboard (GUI)

1. Go to https://vercel.com/new
2. Click "Import Git Repository"
3. Paste your GitHub repo URL
4. Click "Import"
5. Click "Deploy"

## Step 3: Add Environment Variables

After deployment starts, add your WalletConnect Project ID:

### Via Vercel Dashboard

1. Go to your project: https://vercel.com/dashboard
2. Select your "nifty-racer" project
3. Go to "Settings" → "Environment Variables"
4. Add new variable:
   - **Key**: `NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID`
   - **Value**: `your_project_id_from_cloud.walletconnect.com`
   - **Environments**: ✅ Production, Preview, Development
5. Click "Save"
6. Redeploy: Go to "Deployments" → Click latest → "Redeploy"

### Via CLI

```bash
vercel env add NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID
# Enter your Project ID when prompted
```

## Step 4: Configure Custom Domain (Optional)

### Using Vercel's Free Subdomain

Your app is automatically available at:
```
https://nifty-racer-YOUR_USERNAME.vercel.app
```

### Using Custom Domain

1. Go to Project Settings → "Domains"
2. Add your domain (e.g., `niffy-racer.com`)
3. Follow DNS instructions for your registrar
4. DNS propagation takes 24-48 hours

## Step 5: Test Live Deployment

1. Open your Vercel deployment URL
2. Click "Connect Wallet"
3. Select your wallet
4. Verify:
   - ✅ Wallet connects successfully
   - ✅ Base Sepolia is detected
   - ✅ ETH balance displays correctly
   - ✅ All UI renders properly
   - ✅ Buttons are responsive

## 📊 Monitoring & Analytics

### View Deployment Logs

```bash
# Real-time logs
vercel logs

# Or via dashboard:
# Deployments → Select deployment → Function logs/Build logs
```

### Performance Insights

1. Go to your project on Vercel
2. Click "Analytics"
3. View:
   - **Web Vitals**: CLS, FCP, LCP
   - **Requests**: API calls, response times
   - **Usage**: Bandwidth, serverless functions

### Enable Vercel Analytics

Add to `/app/layout.tsx` (already included):

```typescript
import { Analytics } from '@vercel/analytics/next'

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
```

## 🔄 Continuous Deployment

Every `git push` to main automatically deploys:

```bash
git add .
git commit -m "Add new feature"
git push origin main
# → Automatic deployment in ~60 seconds!
```

Disable auto-deploy (not recommended):
1. Project Settings → "Git"
2. Toggle "Automatic Deployments" off

## 🛑 Rollback to Previous Deployment

If something breaks:

1. Go to "Deployments" tab
2. Find the last working deployment
3. Click the "..." menu
4. Select "Promote to Production"
5. Done! You're reverted.

## ⚙️ Advanced Configuration

### Build Optimization

Edit `next.config.mjs`:

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  // Enable React Compiler (experimental)
  experimental: {
    reactCompiler: true,
  },
  // Image optimization
  images: {
    unoptimized: false,
    formats: ['image/avif', 'image/webp'],
  },
}

export default nextConfig
```

### Environment Variables by Environment

Use different values for prod/preview/dev:

```bash
# Production only
vercel env add MY_VAR --environments production

# Preview only
vercel env add MY_VAR --environments preview

# Development only (local)
echo "MY_VAR=local_value" >> .env.local
```

### Custom Build Command

Project Settings → "Build & Development Settings":
- **Build Command**: `npm run build`
- **Output Directory**: `.next`
- **Development Command**: `npm run dev`
- **Root Directory**: `./` (if not in root)

## 🐛 Common Deployment Issues

### "Build failed: Module not found"

```bash
# Solution: Ensure all dependencies are in package.json
npm install missing-package
git add package.json package-lock.json
git push
```

### "Environment variables not loading"

1. Verify the variable name matches exactly
2. Check it's in "Production" environment
3. Redeploy after adding variables
4. Use `console.log()` to debug (visible in logs)

### "Wallet not connecting on live site"

1. Check WalletConnect Project ID in env vars
2. Verify Base Sepolia is configured in `/lib/wagmi.ts`
3. Clear browser cache and localStorage
4. Try in incognito mode

### "Build takes too long"

Vercel has a 12-minute timeout. To optimize:

```bash
# Cache dependencies
npm ci  # instead of npm install

# Enable corepack
vercel env add NODE_ENV production
```

## 📈 Performance Optimization

### Reduce Build Size

```bash
# Analyze bundle
npm run build
npm install -g @next/bundle-analyzer
next-bundle-analyzer
```

### Cache Strategy

Vercel automatically caches:
- ✅ Immutable assets (fonts, images with hash)
- ✅ Static pages (ISR)
- ✅ API routes

Cache headers are in `next.config.mjs`:

```javascript
headers: async () => [
  {
    source: '/api/:path*',
    headers: [
      { key: 'Cache-Control', value: 'public, max-age=3600' }
    ]
  }
]
```

### Database Connection Pooling

If adding a database later:

```typescript
// Use connection pooling to avoid timeouts
import { Pool } from 'pg'

const pool = new Pool({
  max: 20,  // Max connections
  idleTimeoutMillis: 30000,
})
```

## 🔐 Security Checklist

Before public launch:

- [ ] Secrets in environment variables (not in code)
- [ ] CORS configured for your domain
- [ ] Rate limiting on API routes
- [ ] Input validation on all forms
- [ ] HTTPS enforced (automatic on Vercel)
- [ ] No console.log with sensitive data
- [ ] Remove testnet-only code before mainnet
- [ ] Test with real funds (small amounts!)

Add CORS headers to API routes:

```typescript
// app/api/route.ts
export async function GET(request: Request) {
  const response = new Response('OK')
  response.headers.set('Access-Control-Allow-Origin', 'https://yourdomain.com')
  return response
}
```

## 📞 Vercel Support

- **Dashboard Alerts**: Get notifications for deployments
- **Email Support**: vercel.com/help → Open support ticket
- **Status Page**: https://www.vercel-status.com
- **Community**: https://github.com/vercel/next.js/discussions

## 🎯 Next Steps After Deployment

1. **Share Your URL**: Deploy is complete! Send to friends
2. **Add Custom Domain**: Make it more professional
3. **Setup Error Tracking**: Add Sentry integration
4. **Monitor Analytics**: Track user behavior
5. **Build Game Features**: Start implementing /race, /shop
6. **Deploy Smart Contracts**: When ready, deploy to Base Sepolia
7. **Go Mainnet**: Move from testnet to production

## 📝 Deployment Checklist

Before going live:

- [ ] Code pushed to GitHub
- [ ] All env vars added to Vercel
- [ ] Deployment succeeds with green checkmark
- [ ] Wallet connects on live site
- [ ] Balance displays correctly
- [ ] No console errors (check DevTools)
- [ ] Mobile responsive works
- [ ] All buttons clickable
- [ ] Testnet faucet link works
- [ ] README mentions testnet-only

## 🎉 You're Live!

Your Nifty Racer app is now deployed to Vercel! 

**Share your deployment URL:**
```
https://nifty-racer-YOUR_USERNAME.vercel.app
```

**Next: Build the game features and deploy smart contracts!**

---

For issues or questions, see `/SETUP.md` or `/README.md`.

**Happy racing on testnet! 🏁**
