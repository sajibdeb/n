#!/bin/bash

# 🎮 Nifty Racer (Testnet) - Quick Start Script
# This script performs basic checks and provides setup guidance

echo "================================"
echo "🎮 Nifty Racer - Quick Start"
echo "================================"
echo ""

# Check Node.js
echo "📋 Checking prerequisites..."
if command -v node &> /dev/null; then
  NODE_VERSION=$(node --version)
  echo "✅ Node.js: $NODE_VERSION"
else
  echo "❌ Node.js not found. Install from https://nodejs.org"
  exit 1
fi

# Check npm
if command -v npm &> /dev/null; then
  NPM_VERSION=$(npm --version)
  echo "✅ npm: $NPM_VERSION"
else
  echo "❌ npm not found"
  exit 1
fi

echo ""
echo "📦 Checking project files..."

# Check key files
FILES=(
  "app/page.tsx"
  "lib/wagmi.ts"
  "app/globals.css"
  "package.json"
  "tsconfig.json"
)

for file in "${FILES[@]}"; do
  if [ -f "$file" ]; then
    echo "✅ $file"
  else
    echo "❌ Missing: $file"
  fi
done

echo ""
echo "🔧 Checking dependencies..."

if [ ! -d "node_modules" ]; then
  echo "⚠️  node_modules not found"
  echo "Run: npm install"
else
  echo "✅ Dependencies installed"
fi

echo ""
echo "================================"
echo "📖 NEXT STEPS"
echo "================================"
echo ""
echo "1️⃣  Get WalletConnect Project ID:"
echo "    Visit: https://cloud.walletconnect.com"
echo "    Create project, copy Project ID"
echo ""
echo "2️⃣  Update /lib/wagmi.ts:"
echo "    Replace 'YOUR_WALLETCONNECT_PROJECT_ID'"
echo ""
echo "3️⃣  Add Base Sepolia to wallet:"
echo "    RPC: https://sepolia.base.org"
echo "    Chain ID: 84532"
echo ""
echo "4️⃣  Get testnet ETH:"
echo "    https://www.coinbase.com/faucets/base-ethereum-sepolia-faucet"
echo ""
echo "5️⃣  Run locally:"
echo "    npm run dev"
echo "    Open: http://localhost:3000"
echo ""
echo "6️⃣  Read documentation:"
echo "    Start with: /CHECKLIST.md"
echo ""
echo "================================"
echo "📚 Documentation Files"
echo "================================"
echo ""
echo "📖 /CHECKLIST.md          → Start here! Step-by-step setup"
echo "📖 /README.md             → Project overview & features"
echo "📖 /SETUP.md              → Detailed setup guide"
echo "📖 /DEPLOY.md             → Deploy to Vercel"
echo "📖 /QUICK_REFERENCE.md    → Architecture & file guide"
echo "📖 /INDEX.md              → Documentation index"
echo ""
echo "================================"
echo ""
echo "✅ Ready to build? Follow /CHECKLIST.md!"
echo ""
