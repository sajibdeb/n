# 🚀 Nifty Racer Setup Guide

Complete step-by-step guide to get Nifty Racer (Testnet) up and running.

## Step 1: Prerequisites

- **Node.js**: 18.0.0 or higher ([Download](https://nodejs.org))
- **npm or yarn**: Comes with Node.js
- **Git**: For version control ([Download](https://git-scm.com))
- **MetaMask or Rainbow Wallet**: For wallet connection
- **Base Sepolia Testnet**: Add to your wallet

## Step 2: Clone & Install Dependencies

```bash
# Clone the repository
git clone <your-repo-url>
cd nifty-racer

# Install dependencies
npm install
# or
yarn install
```

## Step 3: Get WalletConnect Project ID

This is required for RainbowKit to work with multiple wallet providers.

1. Go to https://cloud.walletconnect.com
2. Click "Create a new project"
3. Select "Web3 Wallet" as the project type
4. Name it "Nifty Racer"
5. Copy the **Project ID** from the dashboard

## Step 4: Configure Environment Variables

### Option A: Using .env.local (Development)

Create a `.env.local` file in the root directory:

```env
NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID=your_project_id_here
```

Replace `your_project_id_here` with the ID from Step 3.

### Option B: Update wagmi.ts Directly

Edit `/lib/wagmi.ts`:

```typescript
const WALLETCONNECT_PROJECT_ID = 'your_project_id_here'
```

## Step 5: Add Base Sepolia to Your Wallet

### MetaMask:

1. Open MetaMask
2. Click the network dropdown (top)
3. Click "Add Network"
4. Fill in:
   - **Network Name**: Base Sepolia
   - **RPC URL**: https://sepolia.base.org
   - **Chain ID**: 84532
   - **Currency Symbol**: ETH
   - **Block Explorer**: https://sepolia.basescan.org
5. Click "Save"

### Other Wallets:
- Rainbow, WalletConnect, Coinbase Wallet should auto-detect Base Sepolia

## Step 6: Get Free Testnet ETH

Visit one of these faucets and enter your wallet address:

- [Coinbase Faucet](https://www.coinbase.com/faucets/base-ethereum-sepolia-faucet)
- [PK910 Faucet](https://sepolia-faucet.pk910.de)

Each faucet gives ~0.5-1 ETH per request (wait 24h between requests).

## Step 7: Run the Development Server

```bash
npm run dev
# or
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

You should see the Nifty Racer home page with a glowing purple title.

## Step 8: Connect Your Wallet

1. Click the "Connect Wallet" button (RainbowKit)
2. Choose your wallet (MetaMask, Rainbow, WalletConnect, etc.)
3. Sign the connection request
4. You should see:
   - Your wallet address
   - Your Base Sepolia ETH balance
   - "START RACE" button enabled

## ✅ You're All Set!

Your Web3 gaming environment is ready. Now you can:

- ✅ Connect/disconnect wallets
- ✅ View your testnet ETH balance
- ✅ Build game features using wagmi hooks

## 📝 Next Steps for Development

### 1. Deploy Smart Contracts

When ready, deploy your game contract to Base Sepolia:

```bash
# Example using Hardhat or Foundry
npx hardhat run scripts/deploy.js --network baseSepolia
```

Then update contract addresses in `/lib/config.ts`.

### 2. Implement Game Pages

- `/app/race/page.tsx` - Main racing game logic
- `/app/shop/page.tsx` - NFT marketplace
- `/app/leaderboard/page.tsx` - Score tracking

### 3. Add Web3 Interactions

Use wagmi hooks in your components:

```typescript
'use client'

import { useContractRead, useContractWrite } from 'wagmi'
import { gameABI } from '@/lib/abi'
import { CONFIG } from '@/lib/config'

export function GameComponent() {
  // Read game data
  const { data: gameData } = useContractRead({
    address: CONFIG.CONTRACTS.GAME_TOKEN as `0x${string}`,
    abi: gameABI,
    functionName: 'getScore',
  })

  // Write to contract
  const { write: submitScore } = useContractWrite({
    address: CONFIG.CONTRACTS.GAME_TOKEN as `0x${string}`,
    abi: gameABI,
    functionName: 'submitScore',
  })

  return (
    <button onClick={() => submitScore({ args: [100] })}>
      Submit Score
    </button>
  )
}
```

### 4. Deploy to Vercel

```bash
git push origin main
# Go to https://vercel.com/new
# Import this repository
# Add NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID in Environment Variables
# Deploy!
```

## 🐛 Troubleshooting

### "Module not found: @rainbow-me/rainbowkit"

```bash
npm install @rainbow-me/rainbowkit wagmi @tanstack/react-query
```

### "WalletConnect Project ID not set"

Make sure you:
1. Got a Project ID from https://cloud.walletconnect.com
2. Added it to `.env.local` OR `/lib/wagmi.ts`
3. Restarted the dev server

### "Wrong network" error

Ensure:
1. Base Sepolia is added to your wallet
2. You're connected to Base Sepolia (not mainnet)
3. Your wallet supports the network

### No ETH balance showing

1. Get testnet ETH from a faucet (Step 6)
2. Wait a minute for transaction to confirm
3. Refresh the page

### RainbowKit button not styling correctly

Check that:
1. `/app/globals.css` imports `@rainbow-me/rainbowkit/styles.css`
2. Tailwind CSS is loading (check browser DevTools)
3. Dark theme is applied to `<html>` tag

## 📚 Learning Resources

- [wagmi Documentation](https://wagmi.sh)
- [RainbowKit Docs](https://www.rainbowkit.com)
- [Base Documentation](https://docs.base.org)
- [Viem Guide](https://viem.sh)
- [Next.js 14 Guide](https://nextjs.org/docs)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)

## 🎨 Customization Tips

### Change Theme Colors

Edit `/app/globals.css`:

```css
:root {
  --neon-pink: #ff006e;        /* Change to your color */
  --neon-purple: #8338ec;      /* Change to your color */
  --neon-cyan: #00f5ff;        /* Change to your color */
}
```

### Modify RPC URLs

Edit `/lib/wagmi.ts`:

```typescript
transports: {
  [baseSepolia.id]: http('https://your-custom-rpc.com'),
}
```

### Add More Networks

```typescript
import { baseSepolia, mainnet } from 'viem/chains'

chains: [baseSepolia, mainnet], // Add mainnet support
```

## 🚀 Production Checklist

Before deploying to production:

- [ ] Replace all testnet RPC URLs with mainnet URLs
- [ ] Update smart contract addresses to mainnet deployments
- [ ] Remove `TESTNET_MODE` flags from code
- [ ] Test with real ETH (start small!)
- [ ] Add error boundaries and fallbacks
- [ ] Set up analytics/monitoring
- [ ] Create terms of service
- [ ] Audit smart contracts
- [ ] Test on mainnet before public launch

## 💡 Tips & Tricks

1. **Use Sepolia Faucets Wisely** - Save your testnet ETH for actual testing
2. **Monitor Gas Usage** - Keep an eye on transaction costs
3. **Use Console Logging** - Add `console.log()` to debug wagmi hooks
4. **Read Contract Events** - Use wagmi's `useContractEvent` for real-time updates
5. **Cache Data** - Use React Query for efficient data fetching

## 📧 Support

If you encounter issues:

1. Check the [Troubleshooting](#-troubleshooting) section
2. Search [GitHub Issues](https://github.com/your-repo/issues)
3. Ask on [wagmi Discord](https://discord.gg/Z8n5aXJbvd)
4. Post on [Ethereum Stack Exchange](https://ethereum.stackexchange.com)

---

**Happy Racing! 🏁**
