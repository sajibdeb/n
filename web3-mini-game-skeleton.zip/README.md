# Nifty Racer (Testnet) 🏁

A Web3 mini-game skeleton built with Next.js 14+, wagmi v2, RainbowKit, and Base Sepolia testnet. Dark synthwave/neon aesthetic with pixel vibes.

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn

### Installation

```bash
# Clone and install dependencies
npm install

# Add your WalletConnect Project ID
# Edit lib/wagmi.ts and replace 'YOUR_WALLETCONNECT_PROJECT_ID'
# Get one from: https://cloud.walletconnect.com
```

### Development

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## 🏗️ Project Structure

```
/app
  /layout.tsx              # Root layout (server component with metadata)
  /layout-client.tsx       # Client providers wrapper (wagmi, RainbowKit, React Query)
  /globals.css             # Tailwind + synthwave/neon theme utilities
  /page.tsx                # Home page - wallet connection & game intro
  /race/page.tsx           # 🏎️ [TODO] Main racing game
  /shop/page.tsx           # 🛍️ [TODO] NFT shop/cosmetics marketplace
  /leaderboard/page.tsx    # 🏆 [TODO] Global rankings & stats

/lib
  /wagmi.ts                # Wagmi config with Base Sepolia setup
  /utils.ts                # Tailwind class utilities (cn function)

/components
  /ui/*                    # shadcn/ui components (Button, Card, etc.)
```

## 🎨 Design Theme

- **Background**: Dark synthwave (`#0a0e27`) with grid overlay
- **Primary Colors**: 
  - Neon Pink: `#ff006e`
  - Neon Purple: `#8338ec`
  - Neon Cyan: `#00f5ff`
  - Neon Orange: `#ffbe0b`
- **Typography**: Geist (sans-serif) + Geist Mono
- **Effects**: Glowing shadows, neon text effects, hover animations

## 🔗 Blockchain Integration

### Wagmi Configuration
- **Network**: Base Sepolia (chainId: 84532)
- **RPC**: https://sepolia.base.org
- **Providers**: RainbowKit + WalletConnect
- **Config File**: `/lib/wagmi.ts`

### Key Hooks Used
- `useAccount()` - Get connected wallet address & connection status
- `useBalance()` - Fetch ETH balance on Base Sepolia
- `useContractRead()` / `useContractWrite()` - [TODO] For game logic
- `useNetwork()` - Network validation

### Setup Steps

1. **Get WalletConnect Project ID**:
   - Visit https://cloud.walletconnect.com
   - Create a new project
   - Copy your Project ID

2. **Update wagmi.ts**:
   ```typescript
   const WALLETCONNECT_PROJECT_ID = 'your_project_id_here'
   ```

3. **Connect Wallet**:
   - Users can now click RainbowKit's `ConnectButton`
   - Auto-connects to Base Sepolia testnet
   - Display address and balance

## 🎮 Game Architecture (TODO)

### /race Route
- Canvas-based endless racer game
- Real-time scoring system
- Mock point accumulation (no real transactions on testnet)
- Wagmi hooks for future on-chain leaderboard updates

### /shop Route
- NFT marketplace for car cosmetics
- Contract write operations with wagmi
- Testnet token for purchases

### /leaderboard Route
- Read from smart contract via wagmi
- Display top player scores
- Sort by time/points/wins

## 📦 Dependencies

### Core
- `next@^14`
- `react@^19`
- `tailwindcss@^4`

### Blockchain
- `wagmi@^2`
- `viem@^2`
- `@rainbow-me/rainbowkit@^2`
- `@tanstack/react-query@^5`

### UI
- `shadcn/ui` (pre-configured)

## 🌐 Deployment

### Deploy to Vercel

```bash
# 1. Push to GitHub
git push origin main

# 2. Import project in Vercel
# https://vercel.com/new

# 3. Environment Variables
# Add in Vercel dashboard (optional if using defaults)
NEXT_PUBLIC_WAGMI_PROJECTID=your_project_id
```

### Testnet Faucet

Get free Base Sepolia ETH:
- https://www.coinbase.com/faucets/base-ethereum-sepolia-faucet
- https://sepolia-faucet.pk910.de

## 🔧 Configuration

### Update Metadata
Edit `/app/layout.tsx` to customize:
- Title and description
- Theme color
- Social media icons

### Custom Theme
Edit `/app/globals.css`:
- Modify CSS variables for colors
- Add new neon glow utilities
- Adjust synthwave background

### Add Smart Contract
1. Create `/lib/abi.ts` with contract ABI
2. Update `/app/page.tsx` with contract address
3. Use `useContractRead` / `useContractWrite` hooks

## 📝 Future Enhancements

- [ ] Smart contract for on-chain scores
- [ ] Multiplayer racing lobbies
- [ ] ERC-721 NFT car skins
- [ ] Token rewards system
- [ ] Mobile optimization
- [ ] Sound effects and animations
- [ ] WebGL racing renderer

## 🛠️ Common Issues

### "WalletConnect Project ID not configured"
- Add your Project ID to `/lib/wagmi.ts`
- Get one at https://cloud.walletconnect.com

### "Testnet ETH not showing"
- Ensure you're on Base Sepolia network in wallet
- Use a testnet faucet to get free ETH

### RainbowKit UI not styling
- Check that `/app/globals.css` imports `@rainbow-me/rainbowkit/styles.css`
- Ensure `dark` class is on `<html>` tag in `/app/layout.tsx`

## 📚 Resources

- [wagmi Docs](https://wagmi.sh)
- [RainbowKit Docs](https://www.rainbowkit.com)
- [Base Docs](https://docs.base.org)
- [Tailwind CSS](https://tailwindcss.com)
- [shadcn/ui](https://ui.shadcn.com)

## 📄 License

Open source - feel free to use, modify, and deploy!

---

**Built with ❤️ using wagmi + RainbowKit + Next.js 14**
