# 🎮 Nifty Racer - Project Structure & Quick Reference

## 📂 File Organization

```
nifty-racer/
├── app/
│   ├── layout.tsx              # Root layout (server) - Metadata & structure
│   ├── layout-client.tsx       # Client wrapper - Providers (wagmi, RainbowKit, React Query)
│   ├── page.tsx                # HOME PAGE - Wallet connect & game intro ⭐
│   ├── globals.css             # Theme, Tailwind, synthwave effects
│   ├── race/
│   │   └── page.tsx            # 🏎️ Racing game (TODO)
│   ├── shop/
│   │   └── page.tsx            # 🛍️ NFT shop (TODO)
│   └── leaderboard/
│       └── page.tsx            # 🏆 Rankings (TODO)
├── lib/
│   ├── wagmi.ts                # ⚙️ Wagmi config + Base Sepolia setup
│   ├── config.ts               # 📋 Game configuration & contract addresses
│   ├── web3-utils.ts           # 🔗 Utility functions for Web3
│   ├── abi.ts                  # 📝 Smart contract ABI templates
│   └── utils.ts                # 🎨 Tailwind utility functions (pre-existing)
├── components/
│   └── ui/                     # 🧩 shadcn/ui components (pre-existing)
├── public/                     # 🖼️ Static assets (pre-existing)
├── README.md                   # 📖 Full documentation
├── SETUP.md                    # 🚀 Setup guide
├── package.json                # 📦 Dependencies
├── tsconfig.json               # TypeScript config
├── next.config.mjs             # Next.js config
└── tailwind.config.ts          # Tailwind config
```

## 🎨 Theme Color Palette

```
Primary Brand: Purple/Pink Neon
├── Neon Pink:    #ff006e    (Glow effects, highlights)
├── Neon Purple:  #8338ec    (Primary CTA buttons)
├── Neon Orange:  #ffbe0b    (Accents)
└── Neon Cyan:    #00f5ff    (Secondary accents)

Background:
├── Dark Base:    #0a0e27    (Main background)
├── Card:         #1a1f3a    (Component backgrounds)
└── Grid:         Pink overlay with opacity

Text:
├── Primary:      White / #ffffff
├── Secondary:    #d0d4e3 (Light gray)
└── Muted:        #6b7280 (Dark gray)
```

## 🔗 Blockchain Setup

### Current Configuration
- **Network**: Base Sepolia (Testnet)
- **Chain ID**: 84532
- **RPC Endpoint**: https://sepolia.base.org
- **Providers**: MetaMask, Rainbow Wallet, WalletConnect, Coinbase Wallet
- **Status**: ✅ Ready for wallet connections & balance queries

### Smart Contract Placeholder Addresses
```typescript
GAME_TOKEN:   0x0000... (TODO: Deploy)
LEADERBOARD:  0x0000... (TODO: Deploy)
NFT_SHOP:     0x0000... (TODO: Deploy)
```

Update these in `/lib/config.ts` after deployment.

## 🎯 Key Features Implemented

✅ **Wallet Connection**
- RainbowKit ConnectButton
- Multi-wallet support
- Auto-detect Base Sepolia

✅ **User Display**
- Wallet address (formatted)
- ETH balance (useBalance hook)
- Network status

✅ **UI/UX**
- Dark synthwave theme
- Neon glowing effects
- Mobile responsive
- Tailwind + shadcn/ui

✅ **Developer Experience**
- TypeScript throughout
- Config file for easy customization
- Web3 utility functions
- Smart contract ABI template
- Comprehensive documentation

## 🔧 Essential Commands

```bash
# Development
npm run dev                    # Start dev server (localhost:3000)
npm run build                  # Build for production
npm run start                  # Run production server
npm run lint                   # Lint code

# Deployment
npm run deploy                 # Deploy to Vercel (if connected)

# Install dependencies
npm install                    # Fresh install
npm install @package/name      # Add new package
```

## 📦 Core Dependencies

```json
{
  "react": "^19",              // React 19 with new features
  "next": "^14",               // Next.js 14+ with App Router
  "tailwindcss": "^4",         // Tailwind v4
  "wagmi": "^2",               // Ethereum wallet integration
  "viem": "^2",                // Lightweight Ethereum client
  "@rainbow-me/rainbowkit": "^2",    // Wallet UI components
  "@tanstack/react-query": "^5",     // Data fetching & caching
  "shadcn-ui": "latest"        // Pre-built UI components
}
```

## 🚀 Quick Start Checklist

- [ ] Run `npm install`
- [ ] Get WalletConnect Project ID from https://cloud.walletconnect.com
- [ ] Update `/lib/wagmi.ts` with your Project ID
- [ ] Add Base Sepolia to your wallet (RPC: https://sepolia.base.org)
- [ ] Get testnet ETH from a faucet
- [ ] Run `npm run dev`
- [ ] Connect wallet on http://localhost:3000
- [ ] See your balance and ready to build!

## 🎮 Game Flow (TODO Items)

```
HOME (page.tsx)
  ├─ Connect Wallet ✅
  ├─ View Balance ✅
  └─ Start Race
      ├─ RACE (race/page.tsx)
      │   ├─ Canvas racing game
      │   ├─ Real-time scoring
      │   └─ Contract interactions
      │
      ├─ SHOP (shop/page.tsx)
      │   ├─ NFT car skins
      │   ├─ Purchase items
      │   └─ Inventory
      │
      └─ LEADERBOARD (leaderboard/page.tsx)
          ├─ Top scores
          ├─ Player stats
          └─ Rankings
```

## 💾 State Management

- **Wagmi Hooks**: Account, balance, contract reads/writes
- **React Query**: Data fetching & caching (via @tanstack/react-query)
- **Component State**: `useState` for local UI state
- **TODO**: Consider Zustand for global game state

## 🔐 Security Notes

⚠️ **Current**:
- Testnet only (no real funds)
- Basic input validation
- No sensitive data stored

📋 **Before Mainnet**:
- [ ] Audit smart contracts
- [ ] Implement rate limiting
- [ ] Add CSRF protection
- [ ] Validate all inputs server-side
- [ ] Use environment variables for secrets
- [ ] Implement proper error handling
- [ ] Add monitoring/logging

## 📊 Performance Tips

- **Images**: Use next/image for optimization
- **Fonts**: Geist + Geist Mono (pre-loaded)
- **CSS**: Tailwind v4 with tree-shaking
- **Bundling**: Turbopack (Next.js 16 default)
- **Caching**: React Query for API responses
- **Code Splitting**: Dynamic imports for heavy components

```typescript
// Example: Lazy load heavy component
const RacingCanvas = dynamic(() => import('./RacingCanvas'), {
  ssr: false, // Don't SSR canvas
  loading: () => <div>Loading race...</div>
})
```

## 🧪 Testing Setup (TODO)

Recommended: Jest + React Testing Library

```typescript
// Example test
import { render, screen } from '@testing-library/react'
import HomePage from '@/app/page'

describe('HomePage', () => {
  it('renders Nifty Racer title', () => {
    render(<HomePage />)
    expect(screen.getByText('NIFTY')).toBeInTheDocument()
  })
})
```

## 📚 Key Files to Understand

| File | Purpose | Priority |
|------|---------|----------|
| `/app/page.tsx` | Home UI & wallet connection | 🔴 High |
| `/lib/wagmi.ts` | Blockchain configuration | 🔴 High |
| `/app/globals.css` | Theme & styles | 🔴 High |
| `/app/layout.tsx` | Provider setup | 🔴 High |
| `/lib/config.ts` | Game configuration | 🟡 Medium |
| `/lib/abi.ts` | Contract templates | 🟡 Medium |
| `/lib/web3-utils.ts` | Helper functions | 🟡 Medium |

## 🚨 Common Gotchas

1. **'use client' in metadata file**
   - ❌ Don't mix 'use client' with metadata exports
   - ✅ Use separate layout-client.tsx for providers

2. **Wrong network**
   - ❌ Users connect to Mainnet instead of Sepolia
   - ✅ Add Base Sepolia via RainbowKit auto-detection

3. **Missing WalletConnect Project ID**
   - ❌ RainbowKit won't work for multi-chain wallets
   - ✅ Get free ID from https://cloud.walletconnect.com

4. **Styles not loading**
   - ❌ Forgot RainbowKit CSS import
   - ✅ Ensure `/app/globals.css` imports `@rainbow-me/rainbowkit/styles.css`

## 🎓 Learning Path

1. **Understand wagmi**: Read [wagmi docs](https://wagmi.sh)
2. **Learn hooks**: `useAccount`, `useBalance`, `useContractRead`
3. **RainbowKit**: [Setup guide](https://www.rainbowkit.com/docs/installation)
4. **Viem basics**: [Getting started](https://viem.sh/docs/getting-started)
5. **Next.js 14**: [New features](https://nextjs.org/docs)
6. **Tailwind v4**: [Upgrade guide](https://tailwindcss.com/blog/tailwindcss-v4)

---

## 📞 Getting Help

**Stuck?** Check in this order:

1. Read the error message carefully
2. Check `/SETUP.md` troubleshooting section
3. Search existing issues on GitHub
4. Ask in wagmi Discord: https://discord.gg/Z8n5aXJbvd
5. Post on Ethereum Stack Exchange

---

**Ready to build? Start with `/SETUP.md` for step-by-step instructions! 🏁**
